# QUIM 360 | Orbit 360

Aplicativo para gerenciar produtos químicos: homologação, uso, armazenamento e compatibilidade, a partir da análise da FDS.

Abrir `quim360/index.html` por um servidor estático (ex.: `python3 -m http.server` na raiz do repositório e acessar `/quim360/`). Sem build, sem backend. Os dados ficam no `localStorage` do navegador (exportar e importar JSON em Configurações).

## O que faz

- **Análise automática**: ao enviar a FDS, o app preenche as etapas que a FDS responde por completo (identificação, validação, data e idioma, triagem GHS, impactos, classificação IMDG, incompatibilidades, controles de armazenamento) e para só nas que exigem o analista: uso e local, cobertura do PGR, pareceres, conflito de segregação e decisão. Tudo que foi preenchido é listado para revisão na decisão.
- **Logo própria nos documentos**: em Configurações, envie sua logo (PNG, JPG ou SVG) e escolha faixa clara ou escura para a capa; vale em Word, PDF e pré-visualização. Dá para voltar à logo Orbit 360 a qualquer momento.
- **Capa** com apresentação do app e logo oficial da Orbit 360 (recorte da arte original) em todas as telas e documentos.
- **Compatibilidade entre produtos**: cada produto contra os demais homologados (matriz de segregação mais reatividade), por produto e em grade.
- **Analisador de FDS**: lê o texto (colado, .txt ou .pdf) e localiza as 16 seções da ABNT NBR 14725, frases H e P, CAS, ponto de fulgor, ONU, classe, grupo de embalagem e incompatibilidades.
- **Assistente de homologação** (contexto de uso e armazenamento + 15 etapas), uma confirmação por etapa: identificação, finalidade, lista de homologados, similaridade (read-across), validação e data/idioma da FDS, triagem GHS, impactos ocupacionais e ambientais (avaliações separadas), interface com o PGR, classificação IMDG, compatibilidade e segregação, pareceres e gatilho do PGR, decisão, plano de ação e saída.
- **Rejeição automática (insumos)**: cancerígeno, mutagênico, teratogênico e PFC/PFAS, por frases H, CAS da lista de alerta e marcação do analista. Marcar "Nenhum" não anula evidência encontrada.
- **Gatilho de reprovação automática (CMR e PFC)**: o app detecta e sinaliza, mas nunca bloqueia, nem para insumos nem para a carga do terminal. A decisão é do responsável técnico, com justificativa, controles de exposição (PGR, PCMSO, plano de emergência) e parecer de Higiene Ocupacional; o produto liberado nessas condições sai como homologado com condicionantes e o relatório registra os gatilhos assumidos. Armazenamento a granel em tanque fica fora da NBR 17160 e segue a NBR 17505 e a NR-20.
- **Via simplificada**: nunca dispensa FDS própria, triagem, IMDG, segregação no local real, pareceres e registro próprio. Divergência relevante a encerra.
- **Armazenamento conjunto pela ABNT NBR 17160:2024**: classe de armazenamento atribuída pelo fluxograma do Anexo D (frases H, número ONU, classe e grupo de embalagem, combustível ou não), matriz de incompatibilidade da Figura 1 (proibido, permitido ou permitido com restrição 1 a 8), regra de 5 m entre ácidos e bases, Tabelas 3 e 4 e quantidades-limite da Tabela 1, aplicados ao local, à auditoria do local e a cada produto contra os homologados. A matriz NR-29 e IMDG fica como referência de carga portuária.
- **Quadro de compatibilidade**: quadro visual (mapa de calor) com os produtos comparados dois a dois pela NBR 17160 e pela reatividade da FDS, filtro por local, detalhe de cada par, grupos que podem dividir o setor de armazém e relatório em Word e PDF.
- **Relatório da análise da FDS**: leitura completa da FDS (validade, 16 seções, GHS, composição e triagem, transporte, classe de armazenamento, controles sugeridos), disponível antes da decisão.
- **Documentos em Word (.docx) e PDF** (arquivos gerados direto, mais pacote .zip com tudo): relatório de homologação, plano de ação, ficha de emergência, rotulagem (GHS e rótulos de risco), envelope de transporte e checklist de treinamento. O envelope segue a estrutura da ABNT NBR 7503 (face do envelope e ficha de emergência), a validar contra o texto licenciado da norma.

- **Alternativas e orientações de substituição**: quando o gatilho de CMR ou PFC é acionado, o app mostra e leva ao relatório orientações para buscar alternativa ao produto ou à composição (por componente identificado e por tipo de perigo), os passos para conduzir a substituição e um campo para registrar as alternativas avaliadas e o resultado. São pontos de partida, não especificação.

- **Análise de risco do armazém (NBR 17160, Seção 5 e Anexo A)**: por local, preenche o que o app sabe (produtos, quantidades, segregação, água de extinção, checklist), registra os aspectos 5.1 e considerações 5.2, avalia cenários por severidade x probabilidade (matriz 5x5 com escalas e situações de enquadramento) e gera o documento em Word e PDF. Os cenários padrão podem ser editados ou desativados por local (com justificativa), e é possível adicionar cenários próprios (origem inspeção, incidente, mudança etc., com severidade e probabilidade obrigatórias) e guardar modelos numa biblioteca da organização.
- **Cenários de risco para treinamento e reuniões** (menu "Cenários de risco" e botão em cada local): documento com uma ficha por cenário (como pode acontecer, o que pode acontecer, como prevenir, perguntas para discussão, anotações) e lista de presença, em Word, PDF, impressão ou texto para e-mail; por local (com os níveis de risco) ou catálogo geral (cenários padrão e biblioteca). O relatório de homologação também traz os cenários do local de armazenamento do produto.
- **Fila de homologação** (menu "Fila de homologação"): importa uma lista de produtos (.xlsx ou .csv) que não traz FDS e a transforma em fila de trabalho. Cada item tem prioridade para levantar a FDS (a composição da lista cita agentes de atenção), situação (FDS a levantar, FDS recebida, em homologação, homologado, descartado) e o botão "Iniciar homologação", que abre o assistente com nome, fabricante e local já preenchidos; os dados da lista ficam só como referência, e a FDS atual é que vale. O cartão "Locais da lista" cadastra em lote os locais da planilha (nome e tipo editáveis) e liga cada produto ao local exato. Gera documento em Word e PDF e CSV. A coluna Empresa não é importada.
- **Importar e exportar locais (.json)** (em Locais de armazenamento): leva o cadastro de locais (área, categoria de segurança, respostas do checklist, inspeções) para outro navegador ou colega; locais com o mesmo nome são atualizados, sem mexer em produtos e na fila.
- **Estoque e histórico**: só o que está armazenado ou em uso agora entra nos cálculos de cada local. Na etapa 11 você informa se o produto já está no terminal e a quantidade: ao homologar, o app registra a entrada sozinho. Se ainda não está, o produto não entra nos cálculos até você registrar a entrada (cartão "Estoque no terminal" do produto); registros antigos sem entrada também não contam. Registre a saída quando sair; ajustes de quantidade também ficam registrados. Todos os movimentos formam o histórico do produto e do local (e saem no inventário do local).
- **Plano de ação com responsáveis e envio por e-mail** (aba "Plano de ação" do produto e etapa 14): cada ação tem responsável, e-mail (um ou mais), prazo e situação (a fazer, enviada, em andamento, concluída). O botão "Enviar e-mail" abre o programa de e-mail com o texto pronto (descrição do produto, local de armazenamento e a ação solicitada); "Enviar por responsável" reúne todas as ações de cada pessoa em uma mensagem. Os contatos ficam salvos e os dados aparecem no documento do plano de ação.
- **Ações do local com envio por e-mail** (em Locais de armazenamento): reúne os cenários de risco alto e crítico da análise de risco (com as medidas de controle no e-mail), as não conformidades do checklist, a inspeção que falta ou venceu e as pendências de inspeção, com responsável, prazo, situação e envio por e-mail (a mensagem traz o local e os produtos em estoque nele).
- **Lista de conferência** (`LISTA-DE-CONFERENCIA.docx`): tabelas e requisitos transcritos da norma e base técnica própria do app, com coluna para o conferente marcar.

## Base técnico-legal

Resolução ANTT 5.947/21 e IMDG; ABNT NBR 17160:2024; NR-20; Manual ABIQUIM; ABNT NBR 14725 e GHS; NR-29 e ABNT NBR 7500; NBR 7503; NR-26; NR-01 e NR-15.

## Limites

- O conteúdo da NBR 17160 foi transcrito de exemplar licenciado: uso interno, não redistribuir. A norma vigente prevalece. A classe de armazenamento e o campo "combustível" dependem da FDS e do julgamento do analista.
- A lista de alerta CMR/PFAS por CAS é de triagem e não exaustiva.
- Pictogramas e rótulos são vetoriais simplificados: use a arte oficial na impressão final.
- Distâncias de isolamento na ficha são valores genéricos por classe: confirme no Manual ABIQUIM pelo número ONU.
- Leitura de PDF carrega o pdf.js do cdnjs; sem rede, cole o texto da FDS.
- Marca: paleta e tipografia da skill marca-orbit360.

## Estrutura

`js/data` dados GHS, transporte e FDS de exemplo | `js/engine.js` regras | `js/fds-parser.js` análise da FDS | `js/docs.js` documentos | `js/render.js` HTML, Word e PDF | `js/wizard.js` etapas | `js/views.js` telas | `vendor/` docx e qrcode-generator (MIT)
