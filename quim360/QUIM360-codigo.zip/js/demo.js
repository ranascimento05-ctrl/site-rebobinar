/* Dados de demonstração (fictícios) para conhecer o fluxo completo. */
(function (O) {
  const S = O.Store, E = O.Engine;

  function produtoBase(chave, localId) {
    const p = E.novoProduto();
    const text = O.SAMPLES[chave];
    O.Wizard.aplicarFds(p, text, O.FDS.parse(text));
    p.ctx = { area: 'Manutenção', atividade: 'Limpeza e desengraxe de peças', localId };
    p.finalidade = 'Limpeza'; p.aplicacao = 'Aplicação manual com pano e imersão de peças';
    p.lista.naLista = false; p.sim.ativa = false;
    p.fds.completa = true; p.fds.atualizada = true;
    return p;
  }

  O.Demo = {
    criar() {
      const pq = S.novoLocal('Contêiner de PQ 01 (demonstração)', 'Contêiner de PQ');
      pq.espacoM = 0; pq.descricao = 'Contêiner com bacia de contenção e ventilação natural.';
      pq.itens = [{ nome: 'Ácido clorídrico 33 % (demonstração)', classeArm: '8B', qtdKg: 300, h: 'H290, H314', grupos: ['acido'], incompativeis: ['base', 'cianeto_sulfeto', 'hipoclorito', 'metais'] }];
      S.salvarLocal(pq);
      const of = S.novoLocal('Oficina mecânica (demonstração)', 'Oficina');
      of.espacoM = 8; of.descricao = 'Armário de inflamáveis aterrado e área ventilada.';
      of.itens = [{ nome: 'Tinta alquídica (demonstração)', classeArm: '3', qtdKg: 80, h: 'H226', grupos: ['organico_combustivel'], incompativeis: ['oxidante'] }];
      S.salvarLocal(of);

      const a = produtoBase('solvente', of.id);
      a.ghs.nenhum = true; a.ghs.confirmado = true;
      a.ocup = { risco: true, subst: 'Avaliar solvente de maior ponto de fulgor.', eng: 'Exaustão local e aterramento na transferência.', adm: 'Permissão de trabalho a quente na área; treinamento prévio.', epi: 'Luvas de nitrila, óculos de ampla visão, respirador para vapores orgânicos.' };
      a.amb = { risco: false, contencao: '', residuos: '', derramamento: '' };
      a.hig = { tlv: true, parecerExigidoOk: true, pgr: 'coberto', dosimetria: false, justificativa: 'Cobertura por avaliação quantitativa de solventes similares.', tlvAgentes: 'Acetato de etila, TLV-TWA 400 ppm' };
      a.imdg.incompativelOperacao = false;
      a.comp.incompDeclaradas = true; a.comp.localOk = 'sim'; a.comp.controles = ['temp_vent', 'sinalizacao', 'bacia']; a.comp.limite = '200 L'; a.comp.qtdKg = 250; a.comp.tempMax = '35 °C';
      a.par = { tem: true, descricao: 'Parecer de Higiene Ocupacional (demonstração)', pgrIndicador: 'nao_requer', pgrPrazo: '', pgrResponsavel: '' };
      a.dec = { valor: 'sim', justificativa: 'Atende aos critérios internos. Homologado para limpeza de peças na oficina.', data: new Date().toISOString(), numero: S.proximoNumero(), sharepoint: '' };
      a.trein.gerar = true; a.status = 'homologado';
      ['fds0', 'ctx', 'ident', 'finalidade', 'lista', 'sim', 'fds', 'fds2', 'ghs', 'impactos', 'pgr', 'imdg', 'compat', 'pareceres', 'decisao', 'plano'].forEach((k) => { a.confirmadas[k] = new Date().toISOString(); });
      a.etapa = 'saida';
      S.salvarProduto(a);

      const b = produtoBase('benzeno', of.id);
      b.ghs.cancerigeno = true; b.ghs.mutagenico = true; b.ghs.confirmado = true;
      b.rejeicaoAuto = true;
      b.dec = { valor: 'nao', justificativa: E.avaliar(b, []).reprovacoes.join(' '), data: new Date().toISOString(), numero: '', sharepoint: '' };
      b.status = 'reprovado';
      ['ctx', 'ident', 'finalidade', 'lista', 'sim', 'fds', 'fds2', 'ghs', 'decisao'].forEach((k) => { b.confirmadas[k] = new Date().toISOString(); });
      b.etapa = 'saida';
      S.salvarProduto(b);

      const al = S.novoLocal('Almoxarifado de limpeza (demonstração)', 'Almoxarifado');
      al.espacoM = 4; al.descricao = 'Prateleiras com bacia de contenção para produtos de limpeza.'; S.salvarLocal(al);
      const c = produtoBase('alcalino', al.id);
      c.ghs.nenhum = true; c.ghs.confirmado = true;
      c.ocup = { risco: true, subst: '', eng: 'Lava-olhos e chuveiro de emergência próximos.', adm: 'Treinamento prévio e sinalização GHS.', epi: 'Luvas de PVC ou neoprene, óculos de ampla visão, protetor facial e avental.' };
      c.amb = { risco: false, contencao: '', residuos: '', derramamento: '' };
      c.hig = { tlv: false, parecerExigidoOk: false, pgr: 'coberto', dosimetria: false, justificativa: 'Sem agente com limite NR-15 ou TLV.', tlvAgentes: '' };
      c.comp.incompDeclaradas = true; c.comp.localOk = 'sim'; c.comp.controles = ['bacia', 'sinalizacao']; c.comp.limite = '100 L'; c.comp.qtdKg = 120;
      c.par = { tem: false, descricao: '', pgrIndicador: 'nao_requer', pgrPrazo: '', pgrResponsavel: '' };
      c.dec = { valor: 'sim', justificativa: 'Atende aos critérios internos.', data: new Date().toISOString(), numero: S.proximoNumero(), sharepoint: '' };
      c.trein.gerar = true; c.status = 'homologado';
      ['ctx', 'ident', 'finalidade', 'lista', 'sim', 'fds', 'fds2', 'ghs', 'impactos', 'pgr', 'imdg', 'compat', 'pareceres', 'decisao', 'plano'].forEach((k) => { c.confirmadas[k] = new Date().toISOString(); });
      c.etapa = 'saida';
      S.salvarProduto(c);

      const mk = (chave, localId, justif) => {
        const q = produtoBase(chave, localId);
        q.ghs.nenhum = true; q.ghs.confirmado = true;
        q.ocup = { risco: true, subst: '', eng: 'Lava-olhos e chuveiro de emergência próximos.', adm: 'Treinamento prévio e sinalização GHS.', epi: 'Luvas de PVC ou neoprene, óculos de ampla visão, protetor facial e avental.' };
        q.amb = { risco: chave === 'hipoclorito', contencao: chave === 'hipoclorito' ? 'Bacia de contenção.' : '', residuos: chave === 'hipoclorito' ? 'Neutralizar e destinar conforme a legislação.' : '', derramamento: chave === 'hipoclorito' ? 'Kit de absorção; impedir chegada à drenagem.' : '' };
        q.hig = { tlv: false, parecerExigidoOk: false, pgr: 'coberto', dosimetria: false, justificativa: 'Sem agente com limite NR-15 ou TLV.', tlvAgentes: '' };
        q.comp.incompDeclaradas = true; q.comp.localOk = 'sim'; q.comp.controles = ['bacia', 'sinalizacao']; q.comp.limite = '100 L'; q.comp.qtdKg = 150;
        q.par = { tem: false, descricao: '', pgrIndicador: 'nao_requer', pgrPrazo: '', pgrResponsavel: '' };
        q.dec = { valor: 'sim', justificativa: justif, data: new Date().toISOString(), numero: S.proximoNumero(), sharepoint: '' };
        q.trein.gerar = true; q.status = 'homologado';
        ['fds0', 'ctx', 'ident', 'finalidade', 'lista', 'sim', 'fds', 'fds2', 'ghs', 'impactos', 'pgr', 'imdg', 'compat', 'pareceres', 'decisao', 'plano'].forEach((k) => { q.confirmadas[k] = new Date().toISOString(); });
        q.etapa = 'saida'; q.natureza = 'insumo'; q.armazenamento = 'embalado';
        S.salvarProduto(q);
      };
      const cl = S.novoLocal('Almoxarifado de cloro (demonstração)', 'Almoxarifado'); cl.espacoM = 6; S.salvarLocal(cl);
      const ac = S.novoLocal('Contêiner de ácidos (demonstração)', 'Contêiner de PQ'); ac.espacoM = 0; S.salvarLocal(ac);
      mk('hipoclorito', cl.id, 'Atende aos critérios internos. Armazenar longe de ácidos.');
      mk('acido', ac.id, 'Atende aos critérios internos. Armazenar longe de hipocloritos e bases.');
    },
  };
})(window.O360 = window.O360 || {});
