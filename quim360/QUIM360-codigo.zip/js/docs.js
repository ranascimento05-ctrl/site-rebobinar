/* Construtores de documentos: cada função devolve uma lista de blocos neutros,
   renderizados depois em HTML (pré-visualização e PDF por impressão) e em Word (.docx). */
(function (O) {
  const T = O.TRANSPORT, G = O.GHS, E = O.Engine;

  const STATUS = {
    em_analise: ['Em análise', 'info'],
    pendente: ['Pendente', 'warn'],
    condicionado: ['Homologado com condicionantes', 'warn'],
    homologado: ['Homologado', 'ok'],
    reprovado: ['Reprovado', 'crit'],
    na_lista: ['Já homologado: encaminhar para aprovação de compra', 'ok'],
  };
  const fmtData = (iso) => { if (!iso) return '—'; const d = new Date(iso); if (isNaN(d)) return iso; return d.toLocaleDateString('pt-BR'); };
  const nz = (v, alt) => (v === undefined || v === null || v === '' ? (alt || '—') : v);
  const sn = (v) => (v === true ? 'Sim' : v === false ? 'Não' : '—');
  const corta = (t, n) => { t = (t || '').replace(/\s+\n/g, '\n').trim(); return t.length > n ? t.slice(0, n).replace(/\s+\S*$/, '') + ' [continua na FDS]' : t; };
  const localDe = (p) => O.Store.local(p.ctx.localId);
  const cfg = () => O.Store.config();
  // quem assina: o assinante definido na análise, ou o padrão da equipe (Configurações)
  const signer = (p) => { const a = (p && p.assina) || {}; const c = cfg(); const nome = (a.nome || '').trim() || c.responsavel || ''; const reg = (a.nome || '').trim() ? (a.registro || '') : (a.registro || c.registro || ''); return { nome, registro: reg, funcao: (a.funcao || '').trim() || 'Responsável técnico', linha: nome ? nome + (reg ? ' | ' + reg : '') : '' }; };
  const nomeG = (k) => (T.RG.find((r) => r[0] === k) || [k, k])[1];
  const ctrlNome = (k) => (T.CONTROLES_ARM.find((c) => c[0] === k) || [k, k])[1];

  function capa(titulo, sub, p, extra) {
    const c = cfg();
    return {
      t: 'cover', titulo, sub,
      meta: [
        ['Produto', nz(p.nome)],
        ['Registro', nz(p.dec.numero, 'sem número de homologação')],
        ['Data', fmtData(new Date().toISOString())],
        [signer(p).funcao, signer(p).linha || 'não informado'],
      ].concat(extra || []),
      org: c.organizacao,
    };
  }

  function linkRegistro(p) {
    if (p.dec.sharepoint) return p.dec.sharepoint;
    return location.href.split('#')[0] + '#/produto/' + p.id;
  }

  // ---------------------------------------------------------------- Relatório
  function relatorio(p, produtos) {
    const av = E.avaliar(p, produtos);
    const st = STATUS[p.status] || STATUS.em_analise;
    const loc = localDe(p);
    const ref = p.sim.refId ? O.Store.produto(p.sim.refId) : null;
    const simp = E.simplificadaVigente(p);
    const B = [];
    B.push(capa('Relatório de homologação de produto químico', 'QUIM 360 | Relatório de Homologação | ' + fmtData(new Date().toISOString()) + ' | ' + nz(p.nome), p));
    B.push({ t: 'callout', tone: st[1], title: 'Decisão: ' + st[0], text: p.dec.justificativa || (av.reprovacoes[0] || av.pendencias[0] || av.condicionantes[0]) || 'Sem pendências registradas.' });
    if (p.status === 'reprovado' || av.reprovacoes.length) B.push({ t: 'list', items: av.reprovacoes });
    if (['homologado', 'condicionado'].includes(p.status) && (p.dec.sobrepoe || []).length) { B.push({ t: 'callout', tone: 'warn', title: 'Gatilhos e pendências assumidos pelo responsável técnico na decisão', text: 'O app sinalizou os pontos abaixo, que normalmente impediriam a homologação. O produto foi liberado com condicionantes, conforme a justificativa técnica registrada.' }); B.push({ t: 'list', items: p.dec.sobrepoe }); }
    if (p.status === 'pendente') B.push({ t: 'list', items: av.pendencias });
    if (p.status === 'condicionado') B.push({ t: 'p', text: 'Condicionantes antes da liberação de uso:', bold: true }, { t: 'list', items: av.condicionantes });
    if (av.alertas.length) B.push({ t: 'callout', tone: 'warn', title: 'Alertas', text: av.alertas.join(' ') });

    B.push({ t: 'h1', text: '1 Identificação e contexto' });
    B.push({ t: 'kv', rows: [
      ['Produto', nz(p.nome)], ['Fornecedor / fabricante', nz(p.fornecedor)], ['Código do fornecedor', nz(p.codigoFornecedor)],
      ['Onde será utilizado', nz([p.ctx.area, p.ctx.atividade].filter(Boolean).join(' | '))],
      ['Finalidade', nz(p.finalidade)], ['Aplicação / forma de uso', nz(p.aplicacao)],
      ['Local de armazenamento', loc ? loc.nome + ' (' + loc.tipo + ')' : '—'],
      ['Natureza do produto', p.natureza === 'carga' ? 'Produto armazenado ou movimentado pelo terminal (carga)' : 'Insumo de operação, manutenção, limpeza ou conservação'],
      ['Forma de armazenamento', p.armazenamento === 'granel' ? 'A granel, em tanque (NBR 17505 e NR-20)' : 'Embalado ou fracionado (NBR 17160)'],
      ['Lista de homologados', p.lista.naLista === true ? 'Já consta: ' + nz(p.lista.numero) : p.lista.naLista === false ? 'Não consta' : '—'],
    ] });

    B.push({ t: 'h1', text: '2 Via de análise' });
    if (simp && ref) {
      B.push({ t: 'callout', tone: 'info', title: 'Via simplificada por similaridade (read-across)', text: 'Produto de referência: ' + ref.nome + ' | ' + nz(ref.dec.numero) + ' | homologado em ' + fmtData(ref.dec.data) + '. O produto recebe registro próprio e não herda o registro da referência.' });
      B.push({ t: 'table', head: ['Item', 'Tratamento nesta via'], widths: [34, 66], rows: [
        ['Etapas 5 e 6: validação da FDS', 'Feita no próprio produto'],
        ['Etapa 7: triagem GHS (cancerígeno, teratogênico, mutagênico, PFC)', 'Feita no próprio produto'],
        ['Etapa 8, 8a e 8b: avaliação ocupacional e ambiental', 'Aproveitada da referência (mesma finalidade e mesmo local)'],
        ['Etapa 9: Higiene Ocupacional e PGR', p.sim.parecerCitaFamilia ? 'Aproveitada da referência (parecer menciona a família química)' : 'Avaliada no próprio produto'],
        ['Etapa 10: classificação IMDG', 'Feita no próprio produto'],
        ['Etapa 11: compatibilidade e segregação', 'Feita para o local real de armazenamento do produto'],
        ['Etapas 12 a 15: pareceres, decisão, relatório, cadastro e treinamento', 'Registro próprio'],
      ] });
      B.push({ t: 'p', text: 'Critérios de equivalência atendidos: mesma família química, mesma forma de aplicação e mesmos componentes perigosos declarados na Seção 3 da FDS.' });
    } else if (p.sim.encerrada) {
      B.push({ t: 'callout', tone: 'warn', title: 'Via simplificada encerrada', text: nz(p.sim.divergencia, 'Divergência relevante identificada em relação ao produto de referência.') + ' A análise completa passou a ser obrigatória.' });
    } else B.push({ t: 'p', text: 'Análise completa.' });

    B.push({ t: 'h1', text: '3 Validação da FDS (ABNT NBR 14725:2023)' });
    const faltam = Object.keys(p.fds.secoesOk || {}).filter((k) => p.fds.secoesOk[k] === false);
    B.push({ t: 'kv', rows: [
      ['16 seções completas', sn(p.fds.completa)], ['Atualizada e em português', sn(p.fds.atualizada)],
      ['Data da revisão', fmtData(p.fds.dataRevisao)], ['Versão', nz(p.fds.versao)],
      ['Seções ausentes', faltam.length ? faltam.join(', ') : 'Nenhuma'],
    ] });

    B.push({ t: 'h1', text: '4 Triagem GHS: perigos CMR e PFC (gatilho de reprovação automática)' });
    const tri = av.tri;
    B.push({ t: 'table', head: ['Critério', 'Resultado'], widths: [34, 66], rows: [
      ['Cancerígeno', tri.criticos.some((c) => c.tipo === 'cancerigeno') ? 'Identificado' : 'Não identificado'],
      ['Mutagênico', tri.criticos.some((c) => c.tipo === 'mutagenico') ? 'Identificado' : 'Não identificado'],
      ['Teratogênico / tóxico à reprodução', tri.criticos.some((c) => c.tipo === 'teratogenico' || c.tipo === 'reprodutivo') ? 'Identificado' : 'Não identificado'],
      ['Contém PFCs / PFAS', tri.criticos.some((c) => c.tipo === 'pfc') ? 'Identificado' : 'Não identificado'],
    ] });
    if (tri.criticos.length) B.push({ t: 'list', items: tri.criticos.map((c) => c.detalhe + ' [' + c.fonte + ']') });
    if (E.cmrCarga(p)) {
      const cm = p.cmr || {};
      B.push({ t: 'callout', tone: 'warn', title: 'Gatilho de reprovação automática acionado: decisão do responsável técnico', text: 'O critério interno de CMR e PFC é sinalizado, mas não bloqueia a homologação. A decisão cabe ao responsável técnico, com justificativa, controles de exposição (PGR, PCMSO, plano de emergência) e parecer de Higiene Ocupacional.' });
      B.push({ t: 'kv', rows: [
        ['Justificativa de não substituição', nz(cm.justificativa)],
        ['Controles de exposição', (cm.controles || []).length ? cm.controles.map((k) => ((O.CMR_CONTROLES || []).find((x) => x[0] === k) || [k, k])[1]).join('\n') : '—'],
        ['Controles implantados e verificados', sn(!!cm.controlesOk)],
      ] });
    }
    B.push({ t: 'kv', rows: [
      ['Palavra de advertência', nz(p.ghs.palavra)],
      ['Frases H', (p.ghs.h || []).length ? p.ghs.h.map((h) => h + ' ' + (G.hText(h) || '')).join('; ') : '—'],
      ['Pictogramas', (p.ghs.pictos || []).length ? p.ghs.pictos.map((c) => c + ' ' + G.PICTO[c]).join('; ') : '—'],
      ['Componentes (CAS)', (p.fds.cas || []).join(', ') || '—'],
    ] });

    B.push({ t: 'h1', text: '5 Impactos ocupacionais e ambientais (avaliações independentes)' });
    const her = simp && p.sim.herda8 ? ' (referência cruzada: ' + nz(ref && ref.dec.numero) + ')' : '';
    B.push({ t: 'h2', text: '5.1 Dimensão ocupacional' + her });
    B.push({ t: 'p', text: 'Riscos ocupacionais significativos: ' + sn(p.ocup.risco) });
    if (p.ocup.risco) B.push({ t: 'table', head: ['Hierarquia de controle', 'Medida'], widths: [30, 70], rows: [['1 Substituição', nz(p.ocup.subst)], ['2 Controles de engenharia', nz(p.ocup.eng)], ['3 Controles administrativos', nz(p.ocup.adm)], ['4 EPI', nz(p.ocup.epi)]] });
    B.push({ t: 'h2', text: '5.2 Dimensão ambiental' + her });
    B.push({ t: 'p', text: 'Perigo ao meio ambiente (toxicidade aquática, bioacumulação, persistência): ' + sn(p.amb.risco) });
    if (p.amb.risco) B.push({ t: 'table', head: ['Controle', 'Medida'], widths: [30, 70], rows: [['Contenção', nz(p.amb.contencao)], ['Destinação de resíduos', nz(p.amb.residuos)], ['Resposta a derramamento', nz(p.amb.derramamento)]] });

    B.push({ t: 'h1', text: '6 Interface com o PGR e Higiene Ocupacional (NR-01 e NR-15)' });
    B.push({ t: 'kv', rows: [
      ['Agente com limite NR-15 ou TLV (ACGIH)', sn(p.hig.tlv) + (p.hig.tlvAgentes ? ': ' + p.hig.tlvAgentes : '')],
      ['Parecer formal de Higiene Ocupacional', p.hig.tlv ? (p.hig.parecerExigidoOk ? 'Exigido e anexado' : 'Exigido e pendente') : 'Não exigido (ausência registrada)'],
      ['Situação no PGR / Inventário de Riscos', p.hig.pgr === 'requer' ? 'Exige atualização' : p.hig.pgr === 'coberto' ? 'Coberto por avaliações existentes' : p.hig.pgr === 'indefinido' ? 'Indefinido: FDS encaminhada ao elaborador' : '—'],
      ['Avaliação quantitativa antes da liberação', sn(p.hig.dosimetria)], ['Justificativa', nz(p.hig.justificativa)],
    ] });

    B.push({ t: 'h1', text: '7 Classificação de transporte (ANTT 5.947/21 e IMDG)' });
    const n20 = E.nr20(p);
    B.push({ t: 'kv', rows: [
      ['Número ONU', nz(p.imdg.onu)], ['Nome apropriado para embarque', nz(p.imdg.nome)],
      ['Classe / subclasse de risco', nz(p.imdg.classe) + (p.imdg.classe ? ' ' + T.classeNome(p.imdg.classe) : '')],
      ['Risco subsidiário', nz(p.imdg.subrisco)], ['Grupo de embalagem', nz(p.imdg.pg)], ['Número de risco', nz(p.imdg.numeroRisco)],
      ['EmS', nz(p.imdg.ems)], ['Poluente marinho', sn(p.imdg.poluente)], ['Ponto de fulgor', p.imdg.pontoFulgor === '' ? '—' : p.imdg.pontoFulgor + ' °C'],
      ['Compatível com as operações', p.imdg.incompativelOperacao ? 'Não' : 'Sim'],
    ] });
    if (n20.aplica) B.push({ t: 'callout', tone: 'warn', title: 'NR-20: ' + n20.categoria, text: n20.texto });

    B.push({ t: 'h1', text: '8 Compatibilidade química e segregação no armazenamento' });
    B.push({ t: 'kv', rows: [
      ['Classe de armazenamento (NBR 17160)', p.armazenamento === 'granel' ? 'Não se aplica: tanque está fora do escopo da NBR 17160 (aplicam-se NBR 17505 e NR-20)' : E.classeArm(p).id + ' | ' + O.NBR17160.nome(E.classeArm(p).id) + ' | ' + E.classeArm(p).motivo],
      ...(p.armazenamento === 'granel' ? [['Requisitos do tanque atendidos', (p.comp.granel || []).length ? p.comp.granel.map((k) => ({ dique: 'Bacia ou dique de contenção (NBR 17505)', nr20: 'Classificação da instalação e prontuário (NR-20)', aterramento: 'Aterramento e proteção contra descargas', incendio: 'Proteção e combate a incêndio', vapores: 'Controle de emissões e vapores', drenagem: 'Drenagem e contenção de águas de combate' }[k] || k)).join('\n') : '—']] : []),
      ['Incompatibilidades declaradas (Seções 7 e 10)', p.comp.incompDeclaradas === true ? (p.comp.incompativeis || []).map(nomeG).join(', ') + (p.comp.incompTexto ? '. ' + p.comp.incompTexto : '') : p.comp.incompDeclaradas === false ? 'Nenhuma declarada' : '—'],
      ['Local avaliado', loc ? loc.nome + ' (' + loc.tipo + ')' : '—'],
      ['Resultado para o local', p.comp.localOk === 'sim' ? 'Compatível' : p.comp.localOk === 'conflito' ? 'Conflito de segregação' : p.comp.localOk === 'insuficiente' ? 'Informação insuficiente na FDS' : '—'],
      ['Solução para o conflito', p.comp.localOk === 'conflito' ? ({ alternativo: 'Local alternativo / segregação física', condicionar: 'Homologação condicionada', reprovar: 'Sem solução viável' }[p.comp.solucao] || '—') : '—'],
      ['Controles adicionais', (p.comp.controles || []).length ? p.comp.controles.map(ctrlNome).join('; ') : '—'],
      ['Estoque máximo', nz(p.comp.limite)], ['Temperatura máxima', nz(p.comp.tempMax)],
    ] });
    if (loc) {
      const cp = E.compatibilidade(p, loc, produtos);
      if (cp.pares.length || cp.grupos.length) {
        const rows = cp.pares.map((x) => [x.com, x.par.join(' / '), (x.codigo === 'R' ? 'Proibido' : x.codigo === 'G' ? 'Permitido' : x.codigo ? 'Restrição ' + x.codigo : '—') + '. ' + x.texto, cp.grupos.filter((g) => g.com === x.com).map((g) => g.a + ' x ' + g.b + ': ' + g.efeito).join('; ') || '—']);
        B.push({ t: 'table', head: ['Item no local', 'Classes', 'Segregação (NBR 17160)', 'Reatividade (FDS)'], widths: [24, 12, 28, 36], rows });
      }
    }

    B.push({ t: 'h1', text: '9 Pareceres externos e gatilho do PGR' });
    B.push({ t: 'kv', rows: [
      ['Parecer arquivado', sn(p.par.tem)], ['Descrição / referência', nz(p.par.descricao)],
      ['Indicador de PGR', p.par.pgrIndicador === 'requer' ? 'PGR: requer atualização' + (p.par.pgrPrazo ? ' | prazo ' + p.par.pgrPrazo : '') + (p.par.pgrResponsavel ? ' | responsável ' + p.par.pgrResponsavel : '') : p.par.pgrIndicador === 'nao_requer' ? 'PGR: não requer atualização (parecer anexo)' : '—'],
    ] });

    B.push({ t: 'h1', text: '10 Decisão e rastreabilidade' });
    B.push({ t: 'kv', rows: [
      ['Decisão', st[0]], ['Número do registro', nz(p.dec.numero)], ['Data da decisão', fmtData(p.dec.data)],
      ['Justificativa técnica / legal', nz(p.dec.justificativa)], ['Checklist de treinamento', p.trein.gerar === true ? 'Gerado' : p.trein.gerar === false ? 'Não solicitado' : '—'],
    ] });
    if (['homologado', 'condicionado'].includes(p.status)) B.push({ t: 'qr', text: linkRegistro(p), cap: 'Cadastro próprio na lista de homologados' + (p.dec.sharepoint ? ' (SharePoint)' : '') });
    B.push({ t: 'h2', text: 'Base técnico-legal consultada' });
    B.push({ t: 'list', items: T.BASE_LEGAL.map((b) => b.sigla + ': ' + b.titulo) });
    B.push({ t: 'p', small: true, text: 'A classe e a matriz de armazenamento seguem a ABNT NBR 17160:2024. A triagem CMR e PFC e as sugestões de controle são apoio à decisão. A decisão formal depende da FDS vigente do fornecedor, do Código IMDG e da avaliação do responsável técnico.' });
    B.push({ t: 'sign', rows: [[signer(p).nome, signer(p).registro ? signer(p).funcao + ' | ' + signer(p).registro : signer(p).funcao]] });
    return B;
  }

  // ---------------------------------------------------------------- Ficha de emergência
  function isolamento(classe) {
    return { '2.1': 100, '2.2': 50, '2.3': 100, '3': 50, '4.1': 50, '4.2': 50, '4.3': 50, '5.1': 50, '5.2': 50, '6.1': 100, '8': 50, '9': 25 }[classe] || 50;
  }
  function trecho(sec, chaves, max, fallback) {
    // extrai as linhas da seção que contêm uma das palavras-chave; sem correspondência, devolve o início da seção (salvo fallback === false)
    const linhas = (sec || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const achadas = linhas.filter((l) => chaves.some((k) => l.toLowerCase().includes(k)));
    if (!achadas.length && fallback === false) return '';
    return corta((achadas.length ? achadas : linhas).join('\n'), max || 500);
  }
  function telefones(p) {
    const c = cfg();
    return [['Corpo de Bombeiros', '193'], ['Defesa Civil', '199'], ['Polícia Rodoviária Federal', '191'], ['Pró-Química (ABIQUIM, 24 h)', '0800 11 8270'], ['Fabricante / fornecedor', p.emerg.telefoneFornecedor || '—'], ['Empresa / expedidor', c.telEmergencia || '—']];
  }

  // Ficha de emergência: sequência de campos da ABNT NBR 7503 (identificação, riscos, EPI, ações em caso de acidente, telefones)
  function prelim(p) {
    return ['homologado', 'condicionado'].includes(p.status) ? [] : [{ t: 'callout', tone: 'warn', title: 'Versão preliminar', text: 'Gerada a partir da leitura da FDS, antes da decisão de homologação. Confira os dados e use somente após a homologação.' }];
  }
  function fichaEmergencia(p) {
    const s = p.fds.secoes || {};
    const B = [];
    B.push(capa('Ficha de emergência', 'QUIM 360 | Ficha de Emergência | ' + nz(p.nome), p, [['Estrutura', 'ABNT NBR 7503, Resolução ANTT 5.947/21 e Manual ABIQUIM']]));
    B.push(...prelim(p));
    B.push({ t: 'imgs', items: [{ svg: O.Pic.painel(p.imdg.numeroRisco, p.imdg.onu, 240), w: 240, h: 120, cap: 'Número de risco e número ONU' }].concat(E.classesDoProduto(p).map((cl, i) => ({ svg: O.Pic.transporte(cl, 110), w: 110, h: 110, cap: (i === 0 ? 'Risco principal ' : 'Risco subsidiário ') + cl }))) });
    B.push({ t: 'table', head: ['Nome apropriado para embarque', 'Classe ou subclasse', 'Grupo de embalagem'], widths: [58, 24, 18], rows: [[nz(p.imdg.nome || p.nome), nz(p.imdg.classe) + (p.imdg.subrisco ? ' (subsidiário ' + p.imdg.subrisco + ')' : ''), nz(p.imdg.pg)]] });
    B.push({ t: 'table', head: ['Aspecto', 'Descrição'], widths: [18, 82], rows: [['Estado físico, cor e odor', trecho(s[9], ['estado físico', 'aspecto', 'odor'], 220, false) || corta(s[9], 220) || '—'], ['Ponto de fulgor e densidade', [p.imdg.pontoFulgor !== '' ? 'Ponto de fulgor: ' + p.imdg.pontoFulgor + ' °C' : '', trecho(s[9], ['densidade'], 100, false)].filter(Boolean).join('. ') || '—']] });
    B.push({ t: 'h1', text: 'Riscos' });
    B.push({ t: 'table', head: ['Fogo e explosão', 'Saúde', 'Meio ambiente'], widths: [34, 33, 33], rows: [[
      trecho(s[5], ['perigo', 'explos', 'inflam', 'vapor', 'combust'], 420),
      ((p.ghs.h || []).length ? p.ghs.h.map((h) => h + ' ' + (G.hText(h) || '')).join('. ') : trecho(s[11], [], 300)),
      nz(p.amb.derramamento ? p.amb.derramamento : trecho(s[12], [], 300)),
    ]] });
    B.push({ t: 'h1', text: 'Equipamento de proteção individual para emergência' });
    B.push({ t: 'p', text: trecho(s[8], ['respirat', 'luva', 'olho', 'óculos', 'roupa', 'vestimenta', 'calçado', 'epi', 'proteção'], 500) || '—' });
    B.push({ t: 'h1', text: 'Em caso de acidente' });
    B.push({ t: 'p', bold: true, text: 'Isolamento inicial: no mínimo ' + isolamento(p.imdg.classe) + ' m em todas as direções (valor genérico por classe: confirme pelo número ONU no Manual ABIQUIM).' });
    B.push({ t: 'table', head: ['Vazamento ou derramamento', 'Fogo', 'Poluição'], widths: [34, 33, 33], rows: [[
      trecho(s[6], ['elimin', 'conter', 'absor', 'isol', 'ferrament', 'recolh'], 520),
      trecho(s[5], ['extin', 'espuma', 'pó', 'co2', 'água', 'bombeiro', 'combat'], 460),
      trecho(s[6], ['pluvial', 'corpo', 'esgoto', 'solo', 'ambient'], 300, false) || trecho(s[12], [], 260) || '—',
    ]] });
    B.push({ t: 'table', head: ['Primeiros socorros', 'Notas para o médico'], widths: [60, 40], rows: [[corta(s[4], 700) || '—', trecho(s[4], ['médico', 'sintoma', 'tratamento'], 300) || ((p.ghs.h || []).slice(0, 4).join(', ') || '—')]] });
    B.push({ t: 'h1', text: 'Telefones de emergência' });
    B.push({ t: 'table', head: ['Órgão', 'Telefone'], widths: [60, 40], rows: telefones(p) });
    B.push({ t: 'kv', rows: [['Observações', p.emerg.observacoes || ''], ['Descarte (Seção 13)', corta(s[13], 240) || '—'], ['Data de emissão', fmtData(new Date().toISOString())]] });
    B.push({ t: 'p', small: true, text: 'Conteúdo extraído da FDS do fornecedor. Em caso de divergência, vale a FDS vigente e o Manual para Atendimento de Emergências com Produtos Perigosos da ABIQUIM.' });
    return B;
  }

  // ---------------------------------------------------------------- Rotulagem
  function agrupaP(p) {
    const lista = (p.ghs.pComb && p.ghs.pComb.length) ? p.ghs.pComb : (p.ghs.p || []);
    const grp = { Prevenção: [], Resposta: [], Armazenamento: [], Disposição: [], Geral: [] };
    lista.forEach((comb) => {
      const first = comb.split('+')[0];
      const txt = comb.split('+').map((c) => G.pText(c) || c).join(' ');
      const k = /^P1/.test(first) ? 'Geral' : /^P2/.test(first) ? 'Prevenção' : /^P3/.test(first) ? 'Resposta' : /^P4/.test(first) ? 'Armazenamento' : 'Disposição';
      grp[k].push(comb + ' ' + txt);
    });
    return grp;
  }

  function rotulagem(p) {
    const c = cfg();
    const h = p.ghs.h || [];
    const pictos = (p.ghs.pictos && p.ghs.pictos.length) ? p.ghs.pictos : G.derive(h).pictos;
    const palavra = p.ghs.palavra || G.derive(h).palavra;
    const grp = agrupaP(p);
    const B = [];
    B.push(capa('Rotulagem', 'QUIM 360 | Rótulo GHS e rótulo de risco | ' + nz(p.nome), p, [['Base', 'ABNT NBR 14725-3, GHS, NR-26 e NBR 7500']]));
    B.push(...prelim(p));
    B.push({ t: 'h1', text: '1 Rótulo de recipiente (GHS)' });
    const inner = [];
    inner.push({ t: 'h2', text: nz(p.nome) });
    if (p.fds.composicao) inner.push({ t: 'p', small: true, text: 'Componentes perigosos: ' + p.fds.composicao });
    if (pictos.length) inner.push({ t: 'imgs', items: pictos.map((x) => ({ svg: O.Pic.ghs(x, 84), w: 84, h: 84, cap: '' })) });
    else inner.push({ t: 'p', small: true, text: 'Sem pictograma de perigo.' });
    inner.push({ t: 'p', bold: true, text: palavra || 'Sem palavra de advertência' });
    inner.push({ t: 'list', items: h.map((x) => x + ' ' + (G.hText(x) || '')) });
    Object.keys(grp).forEach((k) => { if (grp[k].length) { inner.push({ t: 'p', bold: true, small: true, text: 'Precaução: ' + k }); inner.push({ t: 'p', small: true, text: grp[k].join(' ') }); } });
    inner.push({ t: 'p', small: true, text: 'Fornecedor: ' + nz(p.fornecedor) + (p.emerg.telefoneFornecedor ? ' | Emergência: ' + p.emerg.telefoneFornecedor : '') });
    inner.push({ t: 'p', small: true, text: 'Consulte a FDS antes do uso.' });
    B.push({ t: 'box', border: '#dc2626', children: inner });
    if (!(p.ghs.pComb || []).length && !(p.ghs.p || []).length) B.push({ t: 'callout', tone: 'warn', title: 'Frases de precaução ausentes', text: 'Informe as frases P da Seção 2 da FDS para completar o rótulo.' });

    B.push({ t: 'h1', text: '2 Etiqueta de uso e de recipiente fracionado (NR-26)' });
    const mini = [{ t: 'h2', text: nz(p.nome) }];
    if (pictos.length) mini.push({ t: 'imgs', items: pictos.map((x) => ({ svg: O.Pic.ghs(x, 56), w: 56, h: 56, cap: '' })) });
    mini.push({ t: 'p', bold: true, text: palavra || '' });
    mini.push({ t: 'p', small: true, text: h.slice(0, 5).map((x) => x + ' ' + (G.hText(x) || '')).join('; ') });
    mini.push({ t: 'p', small: true, text: 'Local de uso: ' + nz(p.ctx.area) + ' | Armazenamento: ' + nz((localDe(p) || {}).nome) });
    mini.push({ t: 'p', small: true, text: 'Data de fracionamento: ____/____/______   Responsável: ______________________' });
    B.push({ t: 'box', border: '#dc2626', children: mini });

    B.push({ t: 'h1', text: '3 Rótulos de risco para transporte (NBR 7500 e IMDG)' });
    const cl = E.classesDoProduto(p);
    if (cl.length) {
      B.push({ t: 'imgs', items: cl.map((x, i) => ({ svg: O.Pic.transporte(x, 130), w: 130, h: 130, cap: (i === 0 ? 'Risco principal ' : 'Risco subsidiário ') + x + ' | ' + T.classeNome(x) })) });
      B.push({ t: 'kv', rows: [['Número ONU', nz(p.imdg.onu)], ['Nome apropriado para embarque', nz(p.imdg.nome)], ['Grupo de embalagem', nz(p.imdg.pg)], ['Poluente marinho (IMDG)', sn(p.imdg.poluente)]] });
    } else B.push({ t: 'callout', tone: 'warn', title: 'Classe de risco não informada', text: 'Preencha a classificação IMDG (etapa 10) para gerar o rótulo de risco.' });
    B.push({ t: 'p', small: true, text: 'Pictogramas e rótulos vetoriais ilustrativos. Na impressão final, use a arte oficial do GHS e as dimensões exigidas pela NBR 7500 e pelo Código IMDG para o tamanho da embalagem.' });
    return B;
  }

  // ---------------------------------------------------------------- Envelope (ABNT NBR 7503)
  function envelope(p) {
    const cl = E.classesDoProduto(p);
    const inner = [];
    inner.push({ t: 'p', bold: true, text: 'ENVELOPE PARA TRANSPORTE' });
    inner.push({ t: 'p', small: true, text: 'Transporte terrestre de produtos perigosos | ABNT NBR 7503 | Resolução ANTT 5.947/21' });
    inner.push({ t: 'imgs', items: [{ svg: O.Pic.painel(p.imdg.numeroRisco, p.imdg.onu, 280), w: 280, h: 140, cap: 'Número de risco e número ONU' }].concat(cl.map((x, i) => ({ svg: O.Pic.transporte(x, 120), w: 120, h: 120, cap: (i === 0 ? 'Risco principal ' : 'Risco subsidiário ') + x }))) });
    inner.push({ t: 'table', head: ['Nome apropriado para embarque', 'Classe ou subclasse', 'Grupo de embalagem'], widths: [56, 24, 20], rows: [[nz(p.imdg.nome || p.nome), nz(p.imdg.classe) + (p.imdg.subrisco ? ' / ' + p.imdg.subrisco : ''), nz(p.imdg.pg)]] });
    inner.push({ t: 'p', bold: true, text: 'Telefones de emergência' });
    inner.push({ t: 'table', head: ['Órgão', 'Telefone'], widths: [62, 38], rows: telefones(p) });
    inner.push({ t: 'p', bold: true, text: 'Em caso de acidente ou emergência, o condutor deve:' });
    inner.push({ t: 'list', ordered: true, items: [
      'Parar o veículo em local seguro, desligar o motor e acionar o freio de estacionamento.', 'Sinalizar a via e afastar as pessoas, ficando de costas para o vento.', 'Não fumar e eliminar qualquer fonte de ignição.',
      'Acionar os telefones de emergência informando número ONU, nome do produto, local e quantidade.', 'Não tocar no produto nem tentar conter o vazamento sem EPI e treinamento.', 'Entregar a ficha de emergência e os documentos do transporte à equipe de resposta.',
    ] });
    inner.push({ t: 'p', bold: true, text: 'Contém: ficha de emergência, documento fiscal e documentos do transporte.' });
    inner.push({ t: 'kv', rows: [['Expedidor', ''], ['Destinatário', ''], ['Veículo (placa) e condutor', '']] });
    // a primeira página é a face do envelope; a capa da marca fica na ficha de emergência que vai dentro dele
    const B = [...prelim(p), { t: 'box', border: '#c2410c', bg: '#fdba74', children: inner }, { t: 'pagebreak' }];
    return B.concat(fichaEmergencia(p));
  }

  // ---------------------------------------------------------------- Treinamento
  function treinamento(p) {
    const loc = localDe(p);
    const sg = E.sugestoes(p);
    const split = (t) => (t || '').split(/\n|\.\s+(?=[A-ZÁÉÍÓÚÂÊÔÃÕ])/).map((x) => x.trim()).filter(Boolean);
    const B = [];
    B.push(capa('Checklist de treinamento', 'QUIM 360 | Treinamento: manuseio, armazenamento e descarte | ' + nz(p.nome), p));
    B.push({ t: 'h1', text: '1 Antes de manusear' });
    B.push({ t: 'check', items: ['FDS em português disponível no ponto de uso e lida pelo grupo.', 'Rótulo GHS legível em todos os recipientes, inclusive fracionados.', 'Pictogramas e frases H explicados: ' + ((p.ghs.h || []).slice(0, 6).join(', ') || 'conforme FDS') + '.', 'EPI disponível e em bom estado.', 'Local de uso confirmado: ' + nz(p.ctx.area) + '.'] });
    B.push({ t: 'h1', text: '2 Manuseio' });
    const man = [].concat(split(p.ocup.eng), split(p.ocup.adm), split(p.ocup.epi));
    B.push({ t: 'check', items: man.length ? man : sg.ocup.eng.concat(sg.ocup.adm, sg.ocup.epi) });
    B.push({ t: 'h1', text: '3 Armazenamento' });
    const arm = ['Armazenar somente em: ' + (loc ? loc.nome + ' (' + loc.tipo + ')' : 'local aprovado') + '.', 'Respeitar a segregação: ' + (p.comp.incompativeis || []).map(nomeG).join(', ') + (p.comp.incompativeis && p.comp.incompativeis.length ? ' não podem ficar junto.' : 'sem incompatibilidade declarada, conferir a matriz.')];
    (p.comp.controles || []).filter((x) => x !== 'nenhum').forEach((x) => arm.push(ctrlNome(x) + '.'));
    if (p.comp.limite) arm.push('Estoque máximo: ' + p.comp.limite + '.'); if (p.comp.tempMax) arm.push('Temperatura máxima: ' + p.comp.tempMax + '.');
    if (E.nr20(p).aplica) arm.push('NR-20: sem fontes de ignição, aterramento e equipamentos adequados à área.');
    B.push({ t: 'check', items: arm });
    B.push({ t: 'h1', text: '4 Descarte e resíduos' });
    const dsc = split(p.amb.residuos).concat(split(p.fds.secoes && p.fds.secoes[13] ? corta(p.fds.secoes[13], 300) : ''));
    B.push({ t: 'check', items: dsc.length ? dsc : ['Destinar resíduos e embalagens conforme a Seção 13 da FDS e a ABNT NBR 10004.'] });
    B.push({ t: 'h1', text: '5 Emergência' });
    B.push({ t: 'check', items: ['Localização de lava-olhos, chuveiro e kit de derramamento demonstrada.', 'Primeiros socorros: ' + (corta((p.fds.secoes || {})[4], 220) || 'conforme Seção 4 da FDS') , 'Contatos: Pró-Química 0800 11 8270 | Bombeiros 193.', 'Derramamento: ' + (corta(p.amb.derramamento || (p.fds.secoes || {})[6], 220) || 'conforme Seção 6 da FDS')] });
    B.push({ t: 'h1', text: '6 Verificação de aprendizado' });
    B.push({ t: 'check', items: ['O participante identifica o perigo principal do produto no rótulo.', 'O participante cita o que não pode ser armazenado junto.', 'O participante demonstra o uso correto do EPI.', 'O participante sabe a quem acionar em derramamento.'] });
    B.push({ t: 'h1', text: '7 Registro de presença' });
    const rows = []; for (let i = 0; i < 10; i++) rows.push(['', '', '', '']);
    B.push({ t: 'table', head: ['Nome', 'Matrícula', 'Assinatura', 'Data'], widths: [38, 18, 30, 14], rows, tall: true });
    B.push({ t: 'sign', rows: [['Instrutor', ''], [signer(p).nome, signer(p).registro ? signer(p).funcao + ' | ' + signer(p).registro : signer(p).funcao]] });
    return B;
  }

  // ---------------------------------------------------------------- Plano de ação
  function planoAcao(p, produtos) {
    const av = E.avaliar(p, produtos);
    const ok = ['homologado', 'condicionado'].includes(p.status);
    const loc = localDe(p);
    const lim = cfg().anosValidadeFDS;
    const linhas = (t) => String(t || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const A = [];
    const add = (acao, origem, resp, prazo, sit) => { if (acao && !A.some((x) => x[1] === acao)) A.push([String(A.length + 1), acao, origem, resp || '', prazo || '', sit || 'A fazer']); };
    const st = D_STATUS(p);
    if (p.status === 'reprovado') {
      av.reprovacoes.forEach((r) => add('Comunicar a reprovação ao solicitante e ao fornecedor. Motivo: ' + r.replace(/^Critério interno \(GHS\): /, ''), 'Etapa 13 | Decisão', 'Responsável técnico', '', 'A fazer'));
      add('Buscar produto substituto sem cancerígeno, mutagênico, teratogênico ou PFC e iniciar nova homologação', 'Hierarquia de controle: substituição', 'Solicitante', '', 'A fazer');
      add('Manter o registro de reprovação no cadastro de produtos', 'Rastreabilidade', 'Responsável técnico', '', 'A fazer');
    }
    av.pendencias.forEach((x) => add(x, 'Pendência da análise', 'Responsável técnico', '', 'Pendente'));
    av.condicionantes.forEach((x) => add(x, 'Condicionante de liberação', 'Responsável técnico', '', 'Pendente'));
    if (p.par.pgrIndicador === 'requer') add('Atualizar o PGR e o Inventário de Riscos com este produto antes da liberação de uso', 'NR-01 | Etapa 12', p.par.pgrResponsavel, p.par.pgrPrazo ? fmtData(p.par.pgrPrazo) : '', 'Pendente');
    if (E.cmrCarga(p)) {
      (p.cmr.controles || []).forEach((k) => add('Controle de exposição CMR ou PFC: ' + ((O.CMR_CONTROLES || []).find((x) => x[0] === k) || [k, k])[1], 'Etapa 7 | SST', 'SST / Higiene Ocupacional', 'Antes da liberação', p.cmr.controlesOk ? 'Implantado' : 'Pendente'));
      add('Obter e arquivar o parecer de Higiene Ocupacional para o agente CMR ou PFC', 'NR-01 | NR-15', 'Higiene Ocupacional', 'Antes da liberação', p.hig.parecerExigidoOk ? 'Concluído' : 'Pendente');
    }
    if (ok && p.armazenamento === 'granel') ['dique', 'nr20', 'aterramento', 'incendio', 'vapores', 'drenagem'].filter((k) => !(p.comp.granel || []).includes(k)).forEach((k) => add('Tanque: ' + ({ dique: 'confirmar bacia ou dique de contenção (NBR 17505)', nr20: 'confirmar classificação da instalação e prontuário (NR-20)', aterramento: 'confirmar aterramento e proteção contra descargas', incendio: 'confirmar proteção e combate a incêndio', vapores: 'confirmar controle de emissões e vapores', drenagem: 'confirmar drenagem e contenção de águas de combate' }[k]), 'NBR 17505 | NR-20', 'Segurança de processo', 'Antes da liberação', 'Pendente'));
    if (p.hig.dosimetria === true) add('Realizar a avaliação quantitativa (dosimetria ou varredura) antes da liberação de uso', 'NR-15 | Etapa 9.3', 'Higiene Ocupacional', '', 'Pendente');
    if (ok) {
      linhas(p.ocup.subst).forEach((x) => add('Substituição: ' + x, 'Etapa 8a | SST', 'Solicitante / SST', 'Antes da liberação'));
      linhas(p.ocup.eng).forEach((x) => add('Controle de engenharia: ' + x, 'Etapa 8a | SST', 'Gestor da área', 'Antes da liberação'));
      linhas(p.ocup.adm).forEach((x) => add('Controle administrativo: ' + x, 'Etapa 8a | SST', 'Gestor da área / SST', 'Antes da liberação'));
      linhas(p.ocup.epi).forEach((x) => add('EPI: ' + x, 'Etapa 8a | SST', 'Gestor da área', 'Antes do primeiro uso'));
      linhas(p.amb.contencao).forEach((x) => add('Contenção: ' + x, 'Etapa 8b | GA', 'Gestor do local', 'Antes do primeiro recebimento'));
      linhas(p.amb.derramamento).forEach((x) => add('Resposta a derramamento: ' + x, 'Etapa 8b | GA', 'Gestor do local', 'Antes do primeiro recebimento'));
      linhas(p.amb.residuos).forEach((x) => add('Resíduos: ' + x, 'Etapa 8b | GA', 'Meio ambiente', 'Antes do primeiro uso'));
      (p.comp.controles || []).filter((x) => x !== 'nenhum').forEach((x) => add('Armazenamento: ' + ctrlNome(x), 'Etapa 11.3 | PSM', 'Gestor do local', 'Antes do primeiro recebimento'));
      if (p.comp.limite) add('Fixar e controlar o estoque máximo de ' + p.comp.limite, 'Etapa 11.3 | PSM', 'Gestor do local', 'Antes do primeiro recebimento');
      if (p.comp.tempMax) add('Garantir temperatura de armazenamento até ' + p.comp.tempMax, 'Seção 7 da FDS | PSM', 'Gestor do local', 'Antes do primeiro recebimento');
      if (loc) {
        const cpx = E.compatibilidade(p, loc, produtos);
        cpx.pares.filter((x) => x.codigo && !['R', 'G'].includes(x.codigo)).forEach((x) => add('NBR 17160, restrição ' + x.codigo + ' com ' + x.com + ': ' + O.NBR17160.OBS[x.codigo], 'NBR 17160 | Figura 1', 'Gestor do local', 'Antes do primeiro recebimento'));
      }
      if (p.comp.localOk === 'conflito') add('Implantar a segregação física ou o local alternativo: ' + (p.comp.observacoes || 'conforme matriz'), 'Etapa 11.2 | PSM', 'Gestor do local', 'Antes do primeiro recebimento', 'Pendente');
      const n20 = E.nr20(p);
      if (n20.aplica) add('NR-20: verificar a classificação da instalação, as áreas classificadas, o aterramento e o prontuário (' + n20.categoria + ')', 'NR-20 | PSM', 'Segurança de processo', 'Antes do primeiro recebimento');
      if (loc && p.armazenamento !== 'granel') {
        if (E.gatilhosLocal) {
          if (p.comp.qtdKg === '' || p.comp.qtdKg == null) add('Informar a quantidade a armazenar em ' + loc.nome + ' para verificar as quantidades-limite da NBR 17160', 'NBR 17160 | Tabela 1', 'Responsável técnico', 'Antes do primeiro recebimento');
          else E.gatilhosLocal(loc, produtos, p).exige.forEach((x) => add(x, 'NBR 17160 | Tabela 1 e Seções 6 a 14', 'Responsável técnico / Gestor do local', 'Antes do primeiro recebimento'));
        }
      }
      if (loc && p.armazenamento !== 'granel') {
        const ct = E.contencaoLocal(loc, produtos, p);
        if (ct.vol) add('Garantir a retenção da água de extinção de incêndio: cerca de ' + (Math.round(ct.total * 10) / 10).toLocaleString('pt-BR') + ' m³ em ' + loc.nome + ' (CPA ' + ct.cpa + ')', 'NBR 17160 | Anexo F', 'Meio ambiente / Engenharia', 'Antes do primeiro recebimento');
        else add('Informar a área do setor e a categoria de segurança de ' + loc.nome + ' para estimar a retenção da água de extinção (Anexo F)', 'NBR 17160 | Anexo F', 'Meio ambiente', 'Antes do primeiro recebimento');
      }
      add('Rotular recipientes e frações conforme o GHS (NBR 14725) e a NR-26', 'Rotulagem', 'Gestor do local', 'Antes do primeiro uso');
      add('Disponibilizar a FDS em português no ponto de uso e no local de armazenamento', 'NR-26', 'Gestor do local', 'Antes do primeiro uso');
      if (p.trein.gerar !== false) add('Treinar a equipe com o checklist de treinamento e arquivar a lista de presença', 'Etapa 14 | SST', 'SST / Gestor da área', 'Antes do primeiro uso');
      add('Disponibilizar a ficha de emergência e o kit de derramamento no local de armazenamento', 'ABIQUIM | NBR 7503', 'Gestor do local', 'Antes do primeiro uso');
      if (p.imdg.classe) add('Usar o envelope e a ficha de emergência em todo transporte do produto', 'NBR 7503 | ANTT 5.947/21', 'Logística', 'Em cada transporte');
      add('Cadastrar o produto na lista de homologados e fixar o QR Code no local de armazenamento', 'Etapa 13 | Rastreabilidade', 'Responsável técnico', 'Na homologação');
      if (p.fds.dataRevisao) { const d = new Date(p.fds.dataRevisao); d.setFullYear(d.getFullYear() + lim); add('Solicitar nova versão da FDS ao fornecedor', 'ABNT NBR 14725', 'Compras / SST', fmtData(d.toISOString())); }
    }
    if (p.status === 'pendente' || (!A.length && p.status === 'em_analise')) add('Registrar o retorno do fornecedor ou do parecer e retomar a análise na etapa pendente', 'Pendência da análise', 'Responsável técnico', '', 'Pendente');
    const B = [];
    B.push(capa('Plano de ação', 'QUIM 360 | Plano de Ação | ' + nz(p.nome), p, [['Situação do produto', st[0]]]));
    B.push({ t: 'callout', tone: st[1], title: 'Situação: ' + st[0], text: p.status === 'condicionado' ? 'Uso liberado somente após as ações marcadas como pendentes.' : p.status === 'homologado' ? 'Ações para colocar o produto em uso com os controles definidos na análise.' : p.status === 'reprovado' ? 'Produto reprovado: ações de encerramento e substituição.' : 'Análise sem decisão: ações para destravar a homologação.' });
    B.push({ t: 'h1', text: 'Ações' });
    B.push({ t: 'table', head: ['Nº', 'Ação', 'Origem', 'Responsável', 'Prazo', 'Situação'], widths: [5, 37, 15, 13, 18, 12], rows: A.length ? A : [['1', 'Sem ações geradas', '', '', '', '']] });
    B.push({ t: 'p', small: true, text: 'Responsáveis e prazos em branco devem ser definidos pelo responsável técnico. Os prazos marcados como "antes de" valem a partir da liberação do uso.' });
    B.push({ t: 'sign', rows: [[signer(p).nome, signer(p).registro ? signer(p).funcao + ' | ' + signer(p).registro : signer(p).funcao], ['Aprovação da gestão', '']] });
    return B;
  }
  function D_STATUS(p) { return STATUS[p.status] || STATUS.em_analise; }


  // ---------------------------------------------------------------- Inventário do local (NBR 17160, 6.1.5)
  const ST_TXT = { dentro: 'Dentro do limite', armazem: 'Exige armazém (6.3.1)', analise: 'Definir pela análise de risco', secoes: 'Seções adicionais' };
  function inventarioLocal(local, produtos) {
    const g = E.gatilhosLocal(local, produtos);
    const pseudo = { nome: local.nome, dec: { numero: '' } };
    const B = [capa('Inventário de produtos perigosos', 'QUIM 360 | Inventário e quantidades-limite | ABNT NBR 17160:2024', pseudo, [['Local', local.nome + ' (' + local.tipo + ')'], ['Itens', String(g.itens.length)], ['Massa líquida total', Math.round(g.total).toLocaleString('pt-BR') + ' kg']])];
    B.push({ t: 'h1', text: '1 Inventário (6.1.5)' });
    B.push({ t: 'table', head: ['Produto', 'Classificação', 'Classe de armazenamento', 'Quantidade', 'Setor'], widths: [28, 22, 18, 14, 18], rows: g.itens.length ? g.itens.map((i) => [i.nome, (i.h || []).join(', ') || 'sem frases H informadas', i.arm || 'não definida' + (i.aprox ? ' (aprox.)' : ''), i.qtd != null ? String(i.qtd).replace('.', ',') + ' kg' : 'não informada', local.nome]) : [['Sem itens', '', '', '', '']] });
    if (g.semQtd.length) B.push({ t: 'callout', tone: 'warn', title: 'Quantidade não informada', text: g.semQtd.join('; ') + '. O inventário da NBR 17160 exige a quantidade de cada produto.' });
    B.push({ t: 'h1', text: '2 Quantidades-limite (Tabela 1)' });
    B.push({ t: 'p', small: true, text: 'Quantidade agregada por perigo: massa líquida em kg (gases em L; inflamáveis pelo volume nominal da embalagem, 6.2.8). Itens sem frase H usam a classe de armazenamento e são aproximados.' });
    B.push({ t: 'table', head: ['Perigo', 'Quantidade', 'Limite fora de armazém', 'Situação', 'Passa a valer'], widths: [34, 12, 16, 18, 20], rows: g.cats.length ? g.cats.map((x) => [x.rotulo + (x.aprox ? ' (aprox.)' : '') + ' | ' + x.itens.join(', '), String(Math.round(x.qtd * 100) / 100).replace('.', ',') + ' ' + x.unidade, x.fora != null ? String(x.fora).replace('.', ',') + ' ' + x.unidade : 'não indicado', ST_TXT[x.status], x.status === 'secoes' ? x.secoes : x.status === 'analise' ? x.analise : '—']) : [['Sem dados', '', '', '', '']] });
    if (g.exige.length) { B.push({ t: 'h1', text: '3 O que passa a valer neste local' }); B.push({ t: 'list', items: g.exige }); }
    g.conjuntas.forEach((j) => B.push({ t: 'callout', tone: 'warn', title: j.titulo.split(' |')[0] + ' | classes ' + j.classes.join(', ') + ': ' + Math.round(j.qtd) + ' kg (' + j.faixa + ')', text: j.texto }));
    const ct = E.contencaoLocal(local, produtos);
    B.push({ t: 'h1', text: (g.exige.length ? '4' : '3') + ' Contenção da água de extinção (Anexo F)' });
    if (ct.linhas.length) B.push({ t: 'table', head: ['Produto', 'Pontos', 'CPA', 'Composição'], widths: [34, 10, 10, 46], rows: ct.linhas.map((x) => [x.nome, String(x.pontos), 'CPA ' + x.cpa, x.detalhe.join('; ') || '—']) });
    if (ct.semDados.length) B.push({ t: 'p', small: true, text: 'Sem frases H (fora do cálculo): ' + ct.semDados.join('; ') + '.' });
    const fm = (n) => (Math.round(n * 10) / 10).toLocaleString('pt-BR');
    B.push({ t: 'kv', rows: [['Área do setor', ct.areaM2 ? fm(ct.areaM2) + ' m²' : 'não informada'], ['Categoria de segurança', ct.catK || 'não informada (considerada K1/K2)'], ['Classe de perigo à água do local', 'CPA ' + ct.cpa], ['Volume pela Tabela F.1', ct.vol ? fm(ct.vol.base) + ' m³' : 'informe a área do setor'], ['Volume com fator de CPA', ct.vol ? fm(ct.vol.total) + ' m³' : '—'], ['Volume de material que pode vazar', ct.material ? fm(ct.material) + ' m³' : 'não informado'], ['Volume total a reter', ct.total != null ? fm(ct.total) + ' m³' : '—']] });
    B.push({ t: 'p', small: true, text: O.NBR17160.F1_NOTA + ' O Anexo F é informativo; considere as exigências do corpo de bombeiros e do órgão ambiental.' });
    B.push({ t: 'p', small: true, text: 'As seções 7 a 14 e os anexos exigidos devem ser atendidos conforme o texto da norma vigente. Este quadro orienta a análise e não substitui a decisão do responsável técnico.' });
    B.push({ t: 'sign', rows: [[signer(null).nome, signer(null).funcao], ['Gestor do local', '']] });
    return B;
  }

  // ---------------------------------------------------------------- Relatório da análise da FDS
  function analiseFds(p, produtos) {
    const av = E.avaliar(p, produtos);
    const st = STATUS[av.sugestao] || STATUS.em_analise;
    const idade = E.idadeFds(p);
    const B = [];
    B.push(capa('Relatório da análise da FDS', 'QUIM 360 | Análise da FDS | ' + fmtData(new Date().toISOString()) + ' | ' + nz(p.nome), p, [['Natureza', p.natureza === 'carga' ? 'Produto armazenado pelo terminal (carga)' : p.natureza === 'insumo' ? 'Insumo' : 'Não informada']]));
    const bloqueios = av.reprovacoes.concat(av.pendencias, av.condicionantes);
    B.push({ t: 'callout', tone: av.sugestao === 'reprovado' ? 'crit' : av.sugestao === 'homologado' ? 'ok' : 'warn', title: 'Resultado preliminar da análise: ' + st[0], text: bloqueios.length ? bloqueios.join(' ') : 'Nenhum impedimento identificado nos dados informados. A decisão formal é do responsável técnico.' });
    av.alertas.forEach((a) => B.push({ t: 'callout', tone: 'warn', title: 'Alerta', text: a }));

    B.push({ t: 'h1', text: '1 Identificação e validade da FDS' });
    const sec = p.fds.secoesOk || {};
    const faltam = Object.keys(sec).filter((k) => !sec[k]);
    B.push({ t: 'kv', rows: [
      ['Produto', nz(p.nome)], ['Fornecedor / fabricante', nz(p.fornecedor)], ['Data da revisão', fmtData(p.fds.dataRevisao)], ['Versão', nz(p.fds.versao)],
      ['Idade da FDS', idade == null ? '—' : idade.toFixed(1).replace('.', ',') + ' anos (limite configurado: ' + cfg().anosValidadeFDS + ')'],
      ['Idioma', p.fds.portugues === true ? 'Português' : p.fds.portugues === false ? 'Não identificado como português' : '—'],
      ['Seções localizadas', Object.keys(sec).length ? (Object.keys(sec).length - faltam.length) + ' de 16' : 'FDS não analisada'],
    ] });
    if (Object.keys(sec).length) B.push({ t: 'table', head: ['Seção', 'Título (ABNT NBR 14725)', 'Situação'], widths: [10, 66, 24], rows: O.FDS.SEC_TITLES.map((t, i) => [String(i + 1), t, sec[i + 1] ? 'Localizada' : 'Ausente']) });

    B.push({ t: 'h1', text: '2 Classificação GHS' });
    const dv = G.derive(p.ghs.h || []);
    const pict = (p.ghs.pictos && p.ghs.pictos.length) ? p.ghs.pictos : dv.pictos;
    if (pict.length) B.push({ t: 'imgs', items: pict.map((x) => ({ svg: O.Pic.ghs(x, 72), w: 72, h: 72, cap: G.PICTO[x] })) });
    B.push({ t: 'kv', rows: [['Palavra de advertência', nz(p.ghs.palavra || dv.palavra)]] });
    if ((p.ghs.h || []).length) B.push({ t: 'table', head: ['Frase H', 'Texto'], widths: [14, 86], rows: p.ghs.h.map((h) => [h, G.hText(h) || 'Frase não reconhecida']) });
    else B.push({ t: 'p', text: 'Nenhuma frase H informada ou lida na FDS.' });
    const gp = agrupaP(p);
    const linhasP = Object.keys(gp).filter((k) => gp[k].length).map((k) => [k, gp[k].join('\n')]);
    if (linhasP.length) B.push({ t: 'table', head: ['Precaução', 'Frases P'], widths: [18, 82], rows: linhasP });

    B.push({ t: 'h1', text: '3 Composição e triagem de cancerígeno, mutagênico, teratogênico e PFC' });
    const cas = p.fds.cas || [];
    const marca = (c) => { const m = []; [['cancerigeno', 'cancerígeno'], ['reprotoxico', 'tóxico à reprodução'], ['mutagenico', 'mutagênico'], ['pfas', 'PFAS']].forEach(([k, n]) => { const w = T.WATCH[k].find((x) => x[0] === c); if (w) m.push(n + ' (' + w[1] + ')'); }); return m.join('; '); };
    if (cas.length) B.push({ t: 'table', head: ['CAS', 'Lista de alerta'], widths: [26, 74], rows: cas.map((c) => [c, marca(c) || 'Sem registro na lista de alerta']) });
    const tri = av.tri;
    B.push({ t: 'table', head: ['Critério', 'Resultado'], widths: [34, 66], rows: [
      ['Cancerígeno', tri.criticos.some((c) => c.tipo === 'cancerigeno') ? 'Identificado' : 'Não identificado'],
      ['Mutagênico', tri.criticos.some((c) => c.tipo === 'mutagenico') ? 'Identificado' : 'Não identificado'],
      ['Teratogênico / tóxico à reprodução', tri.criticos.some((c) => c.tipo === 'teratogenico' || c.tipo === 'reprodutivo') ? 'Identificado' : 'Não identificado'],
      ['Contém PFCs / PFAS', tri.criticos.some((c) => c.tipo === 'pfc') ? 'Identificado' : 'Não identificado'],
    ] });
    if (tri.criticos.length) B.push({ t: 'list', items: tri.criticos.map((c) => c.detalhe + ' [' + c.fonte + ']') });
    B.push({ t: 'p', small: true, text: 'Cancerígeno, mutagênico, teratogênico e PFC acionam o gatilho de reprovação automática: o app sinaliza e a decisão é do responsável técnico, com justificativa, controles de exposição e parecer de Higiene Ocupacional.' });

    B.push({ t: 'h1', text: '4 Transporte e armazenamento' });
    const n20 = E.nr20(p); const ca = E.classeArm(p); const cb = E.combustivel(p);
    B.push({ t: 'kv', rows: [
      ['Número ONU', nz(p.imdg.onu)], ['Nome apropriado para embarque', nz(p.imdg.nome)], ['Classe / subclasse', nz(p.imdg.classe) + (p.imdg.subrisco ? ' / ' + p.imdg.subrisco : '')],
      ['Grupo de embalagem', nz(p.imdg.pg)], ['Número de risco', nz(p.imdg.numeroRisco)], ['Ponto de fulgor', p.imdg.pontoFulgor === '' ? '—' : p.imdg.pontoFulgor + ' °C'],
      ['NR-20', n20.aplica ? n20.categoria : 'Não aplicável pelo ponto de fulgor e frases H'],
      ['Classe de armazenamento (NBR 17160)', p.armazenamento === 'granel' ? 'Não se aplica: tanque está fora do escopo da NBR 17160 (NBR 17505 e NR-20)' : ca.id + ' | ' + O.NBR17160.nome(ca.id) + ' | ' + ca.motivo],
      ['Combustível', (cb.valor ? 'Sim' : 'Não') + ' | ' + cb.origem],
      ['Incompatível com (Seções 7 e 10)', (p.comp.incompativeis || []).length ? p.comp.incompativeis.map(nomeG).join(', ') : 'Nenhuma identificada'],
      ['Grupos de reatividade do produto', (p.comp.grupos || []).length ? p.comp.grupos.map(nomeG).join(', ') : '—'],
    ] });
    const lims = O.NBR17160.LIMITES.filter((l) => (p.ghs.h || []).some((c) => l.re.test(c)));
    if (lims.length && p.armazenamento !== 'granel') B.push({ t: 'table', head: ['Perigo', 'Limite fora de armazém', 'Acima do limite'], widths: [38, 24, 38], rows: lims.map((l) => [l.rotulo, l.limite, l.acima]) });

    B.push({ t: 'h1', text: '5 Controles sugeridos pela análise' });
    const sg = E.sugestoes(p);
    const linhasS = [['Substituição', sg.ocup.subst], ['Engenharia', sg.ocup.eng], ['Administrativos', sg.ocup.adm], ['EPI', sg.ocup.epi], ['Contenção ambiental', sg.amb.contencao], ['Resposta a derramamento', sg.amb.derramamento], ['Resíduos', sg.amb.residuos]].filter((x) => x[1].length).map((x) => [x[0], x[1].join('\n')]);
    if (linhasS.length) B.push({ t: 'table', head: ['Tipo', 'Sugestão'], widths: [24, 76], rows: linhasS });
    else B.push({ t: 'p', text: 'Nenhum controle adicional sugerido pelas frases H.' });
    if (sg.controlesArm.length) B.push({ t: 'p', text: 'Controles de armazenamento sugeridos: ' + sg.controlesArm.map(ctrlNome).join('; ') + '.' });

    B.push({ t: 'h1', text: '6 Dados que a FDS não traz e dependem de você' });
    B.push({ t: 'list', items: O.Auto.faltam(p) });
    B.push({ t: 'h2', text: 'Base técnico-legal' });
    B.push({ t: 'list', items: T.BASE_LEGAL.map((b) => b.sigla + ': ' + b.titulo) });
    B.push({ t: 'p', small: true, text: 'Análise automática da FDS: apoio à decisão. Valores lidos do texto devem ser conferidos contra a FDS vigente do fornecedor.' });
    B.push({ t: 'sign', rows: [[signer(p).nome, signer(p).funcao]] });
    return B;
  }

  // ---------------------------------------------------------------- Quadro de compatibilidade
  function quadroCompat(destaque, produtos, tituloLocal, incluir) {
    const lista = E.homologados(produtos).filter((x) => x.armazenamento !== 'granel');
    (incluir || []).forEach((x) => { if (x.armazenamento !== 'granel' && !lista.some((y) => y.id === x.id)) lista.push(x); });
    if (destaque && !lista.some((x) => x.id === destaque.id) && destaque.armazenamento !== 'granel') lista.push(destaque);
    const L = lista.slice().sort((a, b) => ((localDe(a) || {}).nome || '').localeCompare((localDe(b) || {}).nome || '') || a.nome.localeCompare(b.nome));
    const pseudo = { nome: destaque ? destaque.nome : (tituloLocal || 'Produtos homologados'), dec: { numero: '' } };
    const B = [capa('Quadro de compatibilidade', 'QUIM 360 | Compatibilidade entre produtos | ABNT NBR 17160:2024', pseudo, [['Produtos comparados', String(L.length)], ['Critério', 'Matriz de incompatibilidade da NBR 17160 e reatividade pela Seção 10 da FDS']])];
    if (L.length < 2) { B.push({ t: 'callout', tone: 'info', title: 'Quadro indisponível', text: 'São necessários ao menos 2 produtos (homologados, ou o produto em análise mais 1 homologado) em armazenamento embalado.' }); return B; }
    const tom = { incompativel: ['crit', 'X'], restricao: ['warn', null], livre: ['ok', 'OK'], verificar: ['info', '?'] };
    let nProib = 0, nRest = 0, nLivre = 0, nVer = 0; const pares = [];
    const rows = L.map((a, i) => L.map((b, j) => {
      if (i === j) return { txt: '—', tone: 'self' };
      const r = E.compatPar(a, b); const t = tom[r.nivel];
      if (i < j) { if (r.nivel === 'incompativel') nProib++; else if (r.nivel === 'restricao') nRest++; else if (r.nivel === 'livre') nLivre++; else nVer++; if (r.nivel !== 'livre') pares.push([i + 1, j + 1, a, b, r]); }
      return { txt: t[1] || r.codigo || 'R', tone: t[0] };
    }));
    B.push({ t: 'callout', tone: nProib ? 'crit' : nRest ? 'warn' : 'ok', title: nProib + ' par(es) proibido(s), ' + nRest + ' com restrição, ' + nLivre + ' permitido(s)' + (nVer ? ', ' + nVer + ' a verificar' : ''), text: 'Entre ' + L.length + ' produtos, ' + (L.length * (L.length - 1) / 2) + ' pares avaliados.' });
    B.push({ t: 'h1', text: '1 Produtos comparados' });
    B.push({ t: 'table', head: ['Nº', 'Produto', 'Classe de armazenamento', 'Local', 'Registro'], widths: [6, 38, 20, 22, 14], rows: L.map((p, i) => [String(i + 1), p.nome + (destaque && p.id === destaque.id ? ' (em análise)' : ''), E.classeArm(p).id + ' | ' + O.NBR17160.nome(E.classeArm(p).id), (localDe(p) || {}).nome || '—', nz(p.dec.numero)]) });
    B.push({ t: 'h1', text: '2 Quadro comparativo' });
    B.push({ t: 'matrix', labels: L.map((_, i) => String(i + 1)), rows });
    B.push({ t: 'p', small: true, text: 'Legenda: X proibido | número restrição da NBR 17160 (ver observação) | OK permitido | ? classe não definida | — mesmo produto.' });
    B.push({ t: 'h1', text: '3 Pares que exigem atenção' });
    if (!pares.length) B.push({ t: 'callout', tone: 'ok', title: 'Nenhuma restrição', text: 'Todos os pares são permitidos pela matriz e sem reatividade declarada.' });
    else B.push({ t: 'table', head: ['Par', 'Classes', 'Resultado', 'Orientação'], widths: [24, 12, 14, 50], rows: pares.map(([i, j, a, b, r]) => [i + ' x ' + j + '\n' + a.nome + '\n' + b.nome, r.par.join(' x '), (r.nivel === 'incompativel' ? (r.codigo === 'R' ? 'Proibido (matriz)' : 'Proibido (reatividade da FDS)') : E.NIVEL[r.nivel] + (r.codigo && !['R', 'G'].includes(r.codigo) ? ' ' + r.codigo : '')), r.acao + (r.motivos.length ? '\n' + r.motivos.join('\n') : '')]) });
    B.push({ t: 'h1', text: '4 Grupos que podem dividir o mesmo setor de armazém' });
    const grupos = E.gruposCompativeis(L);
    B.push({ t: 'p', text: 'Cada grupo reúne produtos com todos os pares permitidos e sem restrição. Produtos de grupos diferentes devem ficar em setores, contêineres ou armários distintos, ou cumprir as restrições da seção 3.' });
    B.push({ t: 'table', head: ['Grupo', 'Produtos'], widths: [14, 86], rows: grupos.map((g, i) => ['Grupo ' + String.fromCharCode(65 + i), g.map((p) => (L.indexOf(p) + 1) + ' ' + p.nome).join('\n')]) });
    B.push({ t: 'p', small: true, text: 'Produtos a granel em tanque ficam fora do quadro (fora do escopo da NBR 17160). A matriz considera a classe de armazenamento; a incompatibilidade também depende de combustão, gases, corrosivos e substâncias instáveis formadas (item 9.1.1 da norma). Confirme nas Seções 7 e 10 da FDS.' });
    B.push({ t: 'sign', rows: [[signer(destaque || null).nome, signer(destaque || null).funcao]] });
    return B;
  }

  // ---------------------------------------------------------------- Solicitação ao fornecedor
  function solicitacaoFornecedor(p, motivos) {
    return 'Assunto: Solicitação de FDS corrigida: ' + nz(p.nome) + '\n\n' +
      'Prezados,\n\nA análise de homologação do produto ' + nz(p.nome) + ' identificou pendências na FDS:\n' +
      motivos.map((m) => '- ' + m).join('\n') + '\n\nSolicitamos o envio da FDS em português, conforme ABNT NBR 14725:2023, com as 16 seções completas e data de revisão atualizada.\n\nPróximo passo: envio até ____/____/______.\n\n' + cfg().responsavel + (cfg().registro ? ' | ' + cfg().registro : '');
  }

  O.Docs = { signer, inventarioLocal, STATUS, analiseFds, quadroCompat, planoAcao, relatorio, fichaEmergencia, rotulagem, envelope, treinamento, solicitacaoFornecedor, fmtData, linkRegistro, agrupaP };
})(window.O360 = window.O360 || {});
